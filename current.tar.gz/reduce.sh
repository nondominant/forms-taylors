#!/bin/bash

rm current.tar.gz

tar -cvzf current.tar.gz *
